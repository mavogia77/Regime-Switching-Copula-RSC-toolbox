function pdf = Copula_PDF(theta,udata,struct)
% ---- Density functions of the supported copulas -----
% INPUTS:
% theta:        vector or scalar that contains the copula parameters
% data:         Tx2 array with U(0,1) margins
% struct:       structured array that contains the various input arguments
%               that define the model. To obtain run the function
%               CopulaDef.m
% OUTPUTS:       
% pdf:          Tx1 array that contains the pdf value at each point in data
% ------------------------------------------------------------------------
% author: Manthos Vogiatzoglou, 2017
% contact at: vogia@yahoo.com
% ------------------------------------------------------------------------

T = size(udata,1);
u = udata(:,1); v = udata(:,2);

if isstruct(struct) == 0 % for the regime switching copulas
    spec.family = struct;
    struct = spec;
end

switch struct.family
    
    case 'Clayton'
        if isscalar(theta)
            theta = repmat(theta,[T,1]);
        else
            theta = PattonEq(theta,udata,'Clayton');
            theta = max(theta,10^(-6));
            theta = min(theta,40);
        end

        out1=(u.*v).^(-1-theta);
        out2=(u.^(-theta)+v.^(-theta)-1).^((-1./theta) -2);
        pdf=(1+theta).*out1.*out2;
        
    case 'Gumbel'
        if isscalar(theta) == 0
            theta = PattonEq(theta,udata,'Gumbel');
            theta = max(theta,1+10^(-6));
            theta = min(theta,50);
        end

        out1 = gumbel_CDF(theta,udata).*((u.*v).^(-1)).*(((-log(u)).*(-log(v))).^(theta-1));
        out2 = (((-log(u)).^theta + (-log(v)).^theta).^(theta.^(-1)-2));
        out3 = ((((-log(u)).^theta + (-log(v)).^theta).^(theta.^(-1))) + theta -1);
        pdf = out1.*out2.*out3;
    case 'SJC'
        % no time varying here
        k1 =  1./log2(2-theta(2));
        k2 = -1./log2(theta(1));
        k1 = repmat(k1,[T,1]);
        k2 = repmat(k2,[T,1]);
        CL1 = ((1 - (1 - u).^k1).^(k2 - 1).* (1 - u).^(k1 - 1).*(-1 + k1.*(k2.* (-1 + (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(k2.^(-1))) + (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(k2.^(-1)))).* (1 - (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(-k2.^(-1))).^(k1.^(-1)).* (1 - (1 - v).^k1).^(k2 - 1).* (1 - v).^(k1 - 1));
        CL2 = (((-1 + (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(k2.^(-1))).^2) .* ((1 - (1 - u).^k1).^k2 + (1 - (1 - v).^k1).^k2 - (1 - (1 - u).^k1).^k2.* (1 - (1 - v).^k1).^k2).^2);
        CLa = CL1./CL2;

        k1 =  1./log2(2-theta(1));
        k2 = -1./log2(theta(2));
        u  = 1-u;
        v  = 1-v;
        CL3 = ((1 - (1 - u).^k1).^(k2 - 1).* (1 - u).^(k1 - 1).*(-1 + k1.*(k2.* (-1 + (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(k2.^(-1))) + (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(k2.^(-1)))).* (1 - (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(-k2.^(-1))).^(k1.^(-1)).* (1 - (1 - v).^k1).^(k2 - 1).* (1 - v).^(k1 - 1));
        CL4 = (((-1 + (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(k2.^(-1))).^2) .* ((1 - (1 - u).^k1).^k2 + (1 - (1 - v).^k1).^k2 - (1 - (1 - u).^k1).^k2.* (1 - (1 - v).^k1).^k2).^2);
        CLb = CL3./CL4;
        pdf = 0.5*(CLa+CLb);
        
    case 'Gaussian'
        if isscalar(theta)==1
            rho = repmat(theta,[T,1]);
        elseif size(theta,1)< T
            rho = DCCEq(theta, udata, struct);
        else
            rho = theta;
        end

        x = norminv(u); y = norminv(v);

        pdf = (1./(sqrt(1-rho.^2)));
        pdf = pdf.*exp(-((rho.^2.*(x.^2+y.^2))-2*rho.*x.*y)./(2*(1-rho.^2)));
        
    case 't'
        nu = theta(1);

        x = tinv(u,nu); y = tinv(v,nu);
        
        if length(theta)>2 
            Rt = DCCEq(theta,udata,struct);
        else
            Rt = repmat(theta(2),[T,1]);
        end

        nu = repmat(nu,[T,1]);

        out1 = 1./(2*pi*sqrt(1-Rt.^2));
        out2 = (tpdf(x,nu).*tpdf(y,nu)).^(-1);
        out3 = (1 + (x.^2+y.^2-2*Rt.*x.*y)./(nu.*(1-Rt.^2))).^(-1-nu/2);
        pdf = out1.*out2.*out3;
        
end