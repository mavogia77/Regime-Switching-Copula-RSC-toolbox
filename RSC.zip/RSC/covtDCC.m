function [Qt, Qst, dQtdv, dQtda, dQtdb] = covtDCC(params, udata, Q0)
% Function that calculates the covariance matrix and its derivatives w.r.t. the
% parameters of the t - copula. 
% INPUTS:
% params:               3x1 coloumn vector of the DCC equation parameters
%                       (v,a,b)           
% udata:                Tx2 array with uniform margin
% Q0:                   The sample covariance of the data (used for
%                       simulation purposes.)
% OUTPUTS
% Qt:                   2x2xT array of Dynamic Conditional Covariances
% Qst:                  2x2xT array. Each 2x2 matrix of Qst contains the inverse 
%                       square root of the diagonal elements of Qt
% dQtdv:                2x2xT aray. Each 2x2 matrix of dQtdv contains the
%                       analytical derivatives of Qt w.r.t. the degree of
%                       freedom parameter of the t copula
% dQtda:                2x2xT aray. Each 2x2 matrix of dQtda contains the
%                       analytical derivatives of Qt w.r.t. the a parameter
%                       of the DCC equation (2)
% dQtdb:                2x2xT aray. Each 2x2 matrix of dQtdb contains the
%                       analytical derivatives of Qt w.r.t. the b parameter
%                       of the DCC equation (2)
% -----------------------------------------------------------------------
% DCC equation(s): Rt = Qst*Qt*Qst (1)
%                  Qt = (1 - a - b)*Q0 + a * data(t-1,:)'*data(t-1,i) + b*Qt-1 (2)
% ------------------------------------------------------------------------
if nargin == 3
    if size(Q0,1)~=size(Q0,2)
        error('Q0 is a square matrix')
    elseif isreal(eig(Q0))==0
        error('Q0 should be psd, all eigenvalues should be real')
    elseif min(eig(Q0))<0
        error('Q0 should be psd, all eigenvalues should be positive')
    end
end

T = size(udata,1);      


v = params(1); a = params(2); b = params(3);
x = tinv(udata(:,1),v); y = tinv(udata(:,2),v);
z = [x y]; 

% for Qt and Q*t
Qt = zeros(2,2,T); Qst = Qt;
if nargin == 2
    Qt(:,:,1) = cov(z);
else
    Qt(:,:,1) = Q0;
end
Qst(:,:,1)=diag((sqrt(diag(Qt(:,:,1)))).^-1);
% there are three score functions: dQdv, dQda, dQdb

if nargout > 2
    invt_p = tinv(udata,v+10^-6);  invt_m = tinv(udata,v-10^(-6));
    %dxdv = .5*(tinv(udata(:,1),v+10^(-6)) - tinv(udata(:,1),v-10^(-6)))/10^(-6);
    dxdv = .5*(invt_p(:,1) - invt_m(:,1))/10^-6;
    %dydv = .5*(tinv(udata(:,2),v+10^(-6)) - tinv(udata(:,2),v-10^(-6)))/10^(-6);
    dydv = .5*(invt_p(:,2) - invt_m(:,2))/10^-6;
    dQtdv = Qt; dQtda = Qt; dQtdb = Qt;
    %dQ0dv = cov([dxdv dydv]);
    %dp = tinv(udata,v+10^-6); dm = tinv(udata,v-10^(-6));
    dp = invt_p; dm = invt_m;
    dQ0dv = (cov(dp) - cov(dm))/(2*10^(-6));

end

for i = 2:T
    zz = z(i-1,:)'*z(i-1,:); % to speed things up a little bit
    Qt(:,:,i) = (1-a-b)*Qt(:,:,1) + a*zz + b*Qt(:,:,i-1);
    Qst(:,:,i)=diag((sqrt(diag(Qt(:,:,i)))).^-1);
    
    if nargout > 2
        ww = x(i-1).*dydv(i-1)+y(i-1).*dxdv(i-1);
        
        dzdv= [2*x(i-1).*dxdv(i-1) ww; ww 2*y(i-1).*dydv(i-1)]; % to speed things up a little bit
        
        dQtdv(:,:,i) = (1-a-b)*dQ0dv + a*dzdv + b*dQtdv(:,:,i-1);
        
        dQtda(:,:,i) = -Qt(:,:,1) + zz + b*dQtda(:,:,i-1);
        
        dQtdb(:,:,i) = -Qt(:,:,1) + Qt(:,:,i-1) + b*dQtdb(:,:,i-1);
        
    end
        
end





