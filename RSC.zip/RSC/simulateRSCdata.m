function simData = simulateRSCdata(spec, state, theta)
% Function to simulate Regime Switching Copula (RSC) data (two states) with
% static copula parameters in each state
% INPUTS
% spec:                 Structure that contains the model specifications.
%                       Run RSCspec.m to obtain
% state:                Tx1 array of zeros and ones that define the current
%                       regime. If state(i) = 0 this means that in time 
%                       t = i, the state is zero. Run
%                       simulateStateVariable.m to obtain
% theta:                array of RSC regime dependent parameters. Optional
%                       input.
% OUTPUT:                     
% simData:              Tx2 array of RSC copula data (uniform margins) 
%                       defined in spec.

% WARNING:              The code creates 5*numsamples simulated
%                       observations, discards the first 4*numsamples as
%                       burnout and outputs the last numsamples
%                       observations. 
% -------------------------------------------------------------------------
if nargin == 2
    theta = spec.theta0;
end

T = size(state,1);

if strcmp(spec.Regime{1},'t') == 1
    c1 = copularnd('t',theta(2), theta(1), 5*T);

elseif strcmp(spec.Regime{1},'SJC')==1
    c1 = simbiSJC(theta(1:2),5*T);
else
    c1 = copularnd(spec.Regime{1}, theta(1), 5*T);
end
c1 = c1(4*T+1:5*T,:);
x = spec.numparams(1);
if strcmp(spec.Regime{2},'t') == 1
    c2 = copularnd('t',theta(x+2), theta(x+1), 5*T);
    
elseif strcmp(spec.Regime{2},'SJC')==1
    c2 = simbiSJC(theta(x+1:x+2),5*T);
else
    c2 = copularnd(spec.Regime{2}, theta(x+1), 5*T);
end
c2 = c2(4*T+1:5*T,:);
simData = zeros(T,2); 

for i = 1:T
    if state(i) == 0
        simData(i,:) = c1(i,:);
    else
        simData(i,:) = c2(i,:);
    end
end
