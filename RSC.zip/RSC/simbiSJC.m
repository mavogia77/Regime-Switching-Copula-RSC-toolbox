function simdata = simbiSJC(theta,numsamples)
% Simulation of Symmetrised Joe Clayton (SJC) copula.

% For details on the simulation method please read:
% Harry Joe "Multivariate Models and Dependence Concepts"

% Taken with slight modifications from Andrew J Patton's copula toolbox

% INPUTS
% theta:            2x1 array of the form [tauL;tauU], tail dependence
%                   coeffs
% numsamples:       positive scalar, default 1000
% OUTPUT
% simdata:          numsamples x 2 array with uniform margins

if nargin == 1
    numsamples = 1000;
end

T = numsamples; tauL = theta(1) ; tauU = theta(2);
	
tauU = tauU*ones(T,1);

tauL = tauL*ones(T,1);

% drawing from the joe-clayton copula 
temp1 = tau2kappa([tauU,tauL]);
temp2 = tau2kappa([tauL,tauU]);
temp3 = (rand(T,1)<=0.5);	% randomly picking BB7_1 or BB7_2
out1a = bb7_rnd(temp1(find(temp3==0),1),temp1(find(temp3==0),2),sum(temp3==0));
out1b = 1-bb7_rnd(temp2(find(temp3==1),1),temp2(find(temp3==1),2),sum(temp3==1));
out1  = [rand(T,1),[out1a;out1b]];
out1 = sortrows(out1,1);
simdata = out1(:,2:3);