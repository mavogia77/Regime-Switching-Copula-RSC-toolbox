function [Rt, measures, gradient]=DCCEq(params,udata,spec,Q0)
% Calculate the time varying correlations based on the DCC(1,1)
% specification of Engle, given a parameters vector theta and data is a matrix of
% uniform U(0,1) margins
% OUTPUTS
% Rt:           The time varying linear correlations
% measures:     Structure that contains various dependence measures like
%               Kendall's tau and tail dependence

if strcmp(spec.family,'Gaussian') == 1
    if nargin == 3
        [Rt, gradient] = corrDCC(params, udata);
    elseif nargin == 4
        [Rt, gradient] = corrDCC(params, udata,Q0);
    end

elseif strcmp(spec.family,'t') == 1
    if nargin == 3
        [Rt, gradient] = corrtDCC(params, udata);
    elseif nargin == 4
        [Rt, gradient] = corrtDCC(params, udata,Q0);
    end    
    
else
    error('The DCC equation applies only to Gaussian and t copula')
end

if strcmp(spec.family,'t')==1 % taildependence
    aux = sqrt((1-Rt)./(1+Rt));
    nu = params(1);
%    measures.lowertailDep = 2*tcdf(aux*sqrt(nu+1),nu,'upper');
%    measures.uppertailDep = measures.lowertailDep;
    measures.Rt = Rt;
else
    measures.lowertailDep = 0;
    measures.uppertailDep = measures.lowertailDep; 
    measures.Rt = Rt;
end

measures.tau = 2*asin(Rt)/pi;



