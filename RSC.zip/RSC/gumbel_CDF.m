function cdf = gumbel_CDF(theta, data)
% the CDF of the Gambel Copula
% INPUTS:
% theta:        scalar or Tx1 vector of the Gumbel copula parameter
% data:         Tx2 array with uniform U(0,1) margins

u = data(:,1); v = data(:,2);

cdf = exp(-((-log(u)).^theta + (-log(v)).^theta).^(theta.^(-1)));