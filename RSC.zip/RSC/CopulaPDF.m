function out = CopulaPDF(family, data, theta, varargin)
% slight modification of the copulapdf function of matlab
% INPUTS
% family:           String that defines the copula. Values are
%                   'Gaussian','t','Clayton','Gumbel','SJC'.
% data:             Tx2 array with uniform margins
% theta:            array of copula parameters. 
%                   For t copula theta = [rho;dof]

%                   For Gaussian copula theta = rho

%                   For Clayton or Gumbel copula theta is the copulaparam
%                   Clayton: tau = theta/(theta+2); lamdaU = 0;
%                   lamdaL=2^(-1/theta)
%                   Gumbel: tau = (theta - 1)/theta; lamdaU=2-2^(1/theta);
%                   lamdaL = 0, where tau = Kendall's tau and lamdaU and
%                   lamdaL is the upper and lower tail dependence
%
%                   For SJC copula theta = [lamdaU;lamdaL].


% case Gaussian copula
if strcmp(family,'Gaussian') && nargin == 3
    out = copulapdf('Gaussian',data,theta);
elseif strcmp(family,'Gaussian') && nargin ==2
    r = corr(data); rho = r(1,2);
    out = copulapdf('Gaussian',data,rho);

% case t - copula
elseif strcmp(family,'t') && isscalar(theta) == 0
    out = copulapdf('t', data, theta(1), theta(2));
elseif strcmp(family,'t') && isscalar(theta) == 1
    out = copulapdf('t',data,varargin{1},theta);
    
% case Clayton copula
elseif strcmp(family,'Clayton')
    out = copulapdf('Clayton',data,theta);

% case Gumbel copula
elseif strcmp(family,'Gumbel')
    out = copulapdf('Gumbel',data,theta);

% case SJC copula
elseif strcmp(family,'SJC')

% taken from A.J. Patton's copula code
T = size(data(:,1));
u = data(:,1); v = data(:,2);
tauU=repmat(theta(1),[T,1]); tauL=repmat(theta(2),[T,1]);

k1 =  1./log2(2-tauU);
k2 = -1./log2(tauL);
CL1 = ((1 - (1 - u).^k1).^(k2 - 1).* (1 - u).^(k1 - 1).*(-1 + k1.*(k2.* (-1 + (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(k2.^(-1))) + (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(k2.^(-1)))).* (1 - (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(-k2.^(-1))).^(k1.^(-1)).* (1 - (1 - v).^k1).^(k2 - 1).* (1 - v).^(k1 - 1));
CL2 = (((-1 + (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(k2.^(-1))).^2) .* ((1 - (1 - u).^k1).^k2 + (1 - (1 - v).^k1).^k2 - (1 - (1 - u).^k1).^k2.* (1 - (1 - v).^k1).^k2).^2);
CL1 = CL1./CL2;

k1 =  1./log2(2-tauL);
k2 = -1./log2(tauU);
u  = 1-u;
v  = 1-v;
CL3 = ((1 - (1 - u).^k1).^(k2 - 1).* (1 - u).^(k1 - 1).*(-1 + k1.*(k2.* (-1 + (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(k2.^(-1))) + (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(k2.^(-1)))).* (1 - (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(-k2.^(-1))).^(k1.^(-1)).* (1 - (1 - v).^k1).^(k2 - 1).* (1 - v).^(k1 - 1));
CL4 = (((-1 + (-1 + (1 - (1 - u).^k1).^(-k2) + (1 - (1 - v).^k1).^(-k2)).^(k2.^(-1))).^2) .* ((1 - (1 - u).^k1).^k2 + (1 - (1 - v).^k1).^k2 - (1 - (1 - u).^k1).^k2.* (1 - (1 - v).^k1).^k2).^2);
CL3 = CL3./CL4;
out = 0.5*(CL1+CL3);
end
    
    
  