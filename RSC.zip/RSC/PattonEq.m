function [theta, measures]=PattonEq(pars,data,type)
% Function that describes the evolution of the copula parameters through
% time, based on a specification similar to Patton's (see ref).
% INPUTS
% pars:         3x1 vector of parameters for the Patton equation
% data:         Tx2 array with uniform margins
% type:         String, 'Clayton' or 'Gumbel'
%
% OUTPUTS:      
% theta:        Tx1 vector of copula parameter
% measures:     Structure that contains the dependence measures. Values
%               tau:           Kendall's tau
%               lowertailDep:  Lower tail dependence coefficient
%               uppertailDep:  Upper tail dependence coefficient

% Reference:  Patton, A.J., 2006, Modelling Asymmetric Exchange Rate Dependence,

%-------------------------------------------------------------------------------
u = data(:,1); v = data(:,2);
T = size(data,1);
theta = zeros(T,1);
tt = corr(data,'type','Kendall'); % calculate Kendall's tau from data
tt = tt(1,2);
theta(1)= 2*tt./(1-tt);

if strcmp(type,'Clayton') == 1
% the inverse transformation L^(-1)(x) = log(x), for the Clayton copula
    tr = @(x) log(x);
    
elseif strcmp(type,'Gumbel') == 1
% the inverse transformation L^(-1)(x) = log(x-1), for the Gumbel copula   
    tr = @(x) log(x-1);
    
end

for jj = 2:T
   if jj<=10
      psi = pars(1) + pars(3)*tr(theta(jj-1)) + pars(2)*(mean(abs(u(1:jj-1)-v(1:jj-1))));

   else
      psi = pars(1) + pars(3)*tr(theta(jj-1)) + pars(2)*(mean(abs(u(jj-10:jj-1)-v(jj-10:jj-1))));

   end
   if strcmp(type,'Clayton') == 1
      % theta(jj) = 10^(-8)+50*exp(psi)/(1+exp(psi)); % theta belongs to (0,+\infty)
      theta(jj) = exp(psi); 
   elseif strcmp(type,'Gumbel') == 1
       theta(jj) = 1+exp(psi); % theta belongs to (1,+\infty)
   end
end
% Calculate various dependence measures like Kendall's tau and tail
% dependence
if strcmp(type,'Clayton') == 1
    theta = max(10^(-12),theta); % to make sure that theta > 0
    theta = min(30,theta); % to make sure that theta < 30
    measures.tau = theta./(theta + 2);
    measures.uppertailDep = zeros(T,1);
    measures.lowertailDep = 2.^(-1./theta);
    measures.theta = theta;
elseif strcmp(type,'Gumbel') == 1
    theta = max(1+10^(-12),theta); % to make sure that theta > 1
    theta = min(30,theta); % to make sure that theta < 30
    measures.tau = 1-1./theta;
    measures.uppertailDep = 2 - 2.^(1./theta);
    measures.lowertailDep = zeros(T,1);
    measures.theta = theta;
end