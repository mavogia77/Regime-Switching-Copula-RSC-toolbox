function state = simulateStateVariable(p11, p22, T)
% Function to simulate the unobserved state variable (two regimes)
% INPUTS
% p11:              the probability of being in regime zero at time t,
%                   given that the state was at regime zero at time t - 1.
%                   p11 is a scalar in [0,1] or a Tx1 array of real numbers
%                   in [0,1].
% p22:              the probability of being in regime one at time t,
%                   given that the state was at regime one at time t - 1.
%                   p22 is a scalar in [0,1] or a Tx1 array of real numbers
%                   in [0,1].
% T:                positive integer, the number of simulated state
%                   observations
% OUTPUTS:
% state:            Tx1 array of zeros and ones

rng default

l1 = length(p11); l2 = length(p22);

if l1 > 1 && l1 ~= T
    error('p11 should be real in [0,1] or Tx1 array of real numbers in [0,1]')
end

if l2 > 1 && l2 ~= T
    error('p22 should be real in [0,1] or Tx1 array of real numbers in [0,1]')
end

if l1 == 1
    p11 = p11*ones(T,1);
end

if l2 == 1
    p22 = p22*ones(T,1);
end
seed = binornd(1,.5); % s1 is set randomly 0 or 1 with 50% chance

state = -1*ones(T,1);

state(1) = seed;

for i = 1:T-1
    if state(i) == 0
        state(i+1) = binornd(1,1 - p11(i+1));
    elseif state(i) == 1
        state(i+1) = binornd(1,p22(i+1));
    end
end
        
    