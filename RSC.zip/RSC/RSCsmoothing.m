function sp = RSCsmoothing(trprobs, w, x)

% this function performs the smooth filter of Kim
% INPUTS
% trprobs:          2x1 array of transition probabilities p_ii
% w:                Tx2 array of forecast probabilities from the filtering
%                   step 
% x:                Tx2 array of inference probabilities from the filtering
%                   step 
% OUTPUTS:
% sp:               Tx2 array of smoothed probabilities ξ_t|T


T = size(x,1); sp = zeros(size(x));
p11 = trprobs(1); p22 = trprobs(2); %P = [p11 1-p22;1-p11 p22];

sp(T,:)=x(T,:);

for i = 1:T-1
    %sw(T-i,:) = x(T-i,:).*((sw(T-i+1,:)./w(T-i+1,:))*P);
    sp(T-i,1) = x(T-i,1)*sp(T-i+1,1)*p11/w(T-i+1,1) + x(T-i,1)*sp(T-i+1,2)*(1-p11)/w(T-i+1,2);
    sp(T-i,2) = x(T-i,2)*sp(T-i+1,1)*(1-p22)/w(T-i+1,1) + x(T-i,2)*sp(T-i+1,2)*p22/w(T-i+1,2);
end
%spec.ksi0 = sw(1,:)';