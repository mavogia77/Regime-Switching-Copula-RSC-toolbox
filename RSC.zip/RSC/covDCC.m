function [Qt, Qst, dQtda, dQtdb] = covDCC(params, udata, Q0)
% Function that calculates the covariance matrix and its derivatives w.r.t. the
% parameters of the Gaussian - copula. 
% INPUTS:
% params:               2x1 coloumn vector of the DCC equation parameters
%                       (a,b)           
% udata:                Tx2 array with uniform margin
% Q0:                   The sample covariance of the data (used for
%                       simulation purposes).
% OUTPUTS
% Qt:                   2x2xT array of Dynamic Conditional Covariances
% Qst:                  2x2xT array. Each 2x2 matrix of Qst contains the inverse 
%                       square root of the diagonal elements of Qt
% dQtdv:                2x2xT aray. Each 2x2 matrix of dQtdv contains the
%                       analytical derivatives of Qt w.r.t. the degree of
%                       freedom parameter of the t copula
% dQtda:                2x2xT aray. Each 2x2 matrix of dQtda contains the
%                       analytical derivatives of Qt w.r.t. the a parameter
%                       of the DCC equation (2)
% dQtdb:                2x2xT aray. Each 2x2 matrix of dQtdb contains the
%                       analytical derivatives of Qt w.r.t. the b parameter
%                       of the DCC equation (2)
% -----------------------------------------------------------------------
% DCC equation(s): Rt = Qst*Qt*Qst (1)
%                  Qt = (1 - a - b)*Q0 + a * data(t-1,:)'*data(t-1,i) + b*Qt-1 (2)
% ------------------------------------------------------------------------
if nargin == 3
    if size(Q0,1)~=size(Q0,2)
        error('Q0 is a square matrix')
    elseif isreal(eig(Q0))==0
        error('Q0 should be psd, all eigenvalues should be real')
    elseif min(eig(Q0))<0
        error('Q0 should be psd, all eigenvalues should be positive')
    end
end

T = size(udata,1);      


a = params(1); b = params(2);
x = norminv(udata(:,1)); y = norminv(udata(:,2));
z = [x y]; 

% for Qt and Q*t
Qt = zeros(2,2,T); Qst = Qt;
if nargin == 2
    Qt(:,:,1) = cov(z);
else
    Qt(:,:,1) = Q0;
end

Qst(:,:,1)=diag((sqrt(diag(Qt(:,:,1)))).^-1);
% there are two score functions: dQda, dQdb

if nargout > 2
    dQtda = Qt; dQtdb = Qt;
end

for i = 2:T
    zz = z(i-1,:)'*z(i-1,:); % to speed things up a little bit
    Qt(:,:,i) = (1-a-b)*Qt(:,:,1) + a*zz + b*Qt(:,:,i-1);
    Qst(:,:,i)=diag((sqrt(diag(Qt(:,:,i)))).^-1);
    
    if nargout > 2
        
        dQtda(:,:,i) = -Qt(:,:,1) + zz + b*dQtda(:,:,i-1);
        
        dQtdb(:,:,i) = -Qt(:,:,1) + Qt(:,:,i-1) + b*dQtdb(:,:,i-1);
        
    end
        
end
