function [bData, indices] = BlockBootstrap(data, blocklength, numsamples, method)
% this function uses resampling with replacement from an original sample to
% create new samples. When the initial sample is correlated block bootstrap
% is used. Two methods are supported, stationary block bootstrap (sbb) and
% moving block bootstrap (mbb)

% INPUTS:
% data:         Txp array of correlated data to be resampled
% blocklength:  The length of each block
% numsamples:   Number of samples produced. Default is 30
% method:       string that defines the block bootstrap method with values
%               'sbb' or 'mbb', for stationary block bootstrap and moving block
%               bootstrap, respectively. Default is 'sbb'

% OUTPUTS:
% bData:        T x p x numsamples array of resampled data

if nargin == 1
    error('this function needs at least two input arguments')
elseif nargin == 2 
    numsamples = 30;
    method = 'sbb';
elseif nargin == 3
    method = 'sbb';
end

rng('default')

[T,p] = size(data);
b = blocklength;
n = numsamples;

if b > T
    error('the block length should be smaller than the sample size')
end

bData = zeros(T,p,n);
u = zeros(T,1); % the indexes of the sampled data for each bootstrap sample
indices = zeros(T,n);

switch method
    case 'sbb'
       for i=1:n
           u(1) = ceil(T*rand);
           xx = rand(T,1);
           for t=2:T

               if xx(t) < 1/b
                   u(t) = ceil(T*rand);
               else
                   u(t) = min(u(t-1)+1,T);
                   if u(t) == T
                       xx(t+1) = 1/(b+2);
                   end
                       
               end
           end
           bData(:,:,i) = data(u,:);
           indices(:,i) = u;
       end
       
    case 'mbb'
        for i = 1:n
            u = ceil((T - b + 1)*rand(ceil(T/b),1));
            u = bsxfun(@plus,u,0:b-1)';
            u = u(:); u=u(1:T);
            bData(:,:,i) = data(u,:);
            indices(:,i) = u;
        end
end
        
        
