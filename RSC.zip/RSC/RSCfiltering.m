function [fp,ip] = RSCfiltering(theta, data, spec)

% this function performs the Hamilton Filter of the Regime Switching Copula
% models (RSC)
% INPUTS:
% theta:                column vector of model parameters [θ1;θ2;p11;p22;z]
%                       where θ1 θ2 are copula parameters for regimes 1 and
%                       2, p11 and p22 are transition probabilities and z
%                       is the initial value for the filter recursion
% data:                 array of data with uniform U(0,1) margins (columns)
% spec:                 structure array of model specifications
% OUTPUTS:
% fp:                   array of forecast probabilities ξt|t-1, that is the 
%                       probability of being in regime i in time t, given 
%                       the available information at t-1
% ip:                   array of inference probabilities ξt|t, that is the 
%                       probability of being in regime i in time t, given 
%                       the available information at t

%%%%%%% 25/05/2018

T = size(data,1);  fp = .5*ones(T,2);  ip = fp; 

cp1 = theta(1:spec.numparams(1));         % regime 1 copula parameters
cp2 = theta(1+spec.numparams(1):sum(spec.numparams));   % regime 2 copula parameters
%rho = corr(data);
p11 = theta(end - 2);
p22 = theta(end - 1);
z = theta(end);
 
w1= z; w2 = 1-w1; 

%w(1,:)=[w1 w2];

fp = repmat([w1 w2],[T 1]); % forecasted probabilities

%w(1,:)=spec.ksi0';

cc = zeros(T,2); 
cc(:,1) = Copula_PDF(cp1, data, spec.Regime{1});
cc(:,2) = Copula_PDF(cp2, data, spec.Regime{2});
  
for t = 2:T
    
        ip(t-1,:)= fp(t-1,:).*cc(t-1,:)/sum(fp(t-1,:).*cc(t-1,:));
        fp(t,:) = [p11 1-p22;1-p11 p22]*ip(t-1,:)';
end

