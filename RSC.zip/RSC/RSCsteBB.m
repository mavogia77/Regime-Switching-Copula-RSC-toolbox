function [stE, bpars, spec] = RSCsteBB(data, spec, params, est_method, blocklength, numsamples, method)

% this function calculates the block bootstrapped standard errors for the 
% regime switching copula model

% INPUTS
% data:         Tx2 array of copula (uniform) data
% spec:         model specifications
% params:       The array of copula parameters estimated from the whole
%               sample
% est_method:   string with values 'EM' or 'Full MLE', that define the
%               estimation method.
% blocklength:  positive integer that determines the block size, default is 10
% numsamples:   positive integer that determines the bootstrap samples, default is 30
% method:       string that defines the block bootstrap method. Values are
%               'sbb', for stationary block bootstrap and 'mbb' for moving
%               block bootstrap.

% OUTPUTS:
% stE:          Array that contains the standard error of model parameters
% bpars:        the estimated parameters from each bootstrap sample

% some default values

if nargin == 5
    numsamples = 30; method = 'sbb';
elseif nargin == 4
    numsamples = 30; blocklength = 10; method = 'sbb';
elseif nargin == 6
    method = 'sbb';
end

% create the bootstrap samples 
bData = BlockBootstrap(data, blocklength, numsamples, method);
spec.bbmethod = method;
tic
switch est_method
    
    case 'Full MLE'
        if isempty(params) == 1
            params = RSCLogLFit(spec, data); % Full likelihood
            spec.theta0 = params;
        else
            spec.theta0 = params;
        end
            
        l = size(params,1);
        
        bpars = zeros(l,numsamples);
        
        for i = 1:numsamples
            fprintf('Estimating copula parameters for bootstrap sample number: %2i\n',i)
            bpars(:,i) = RSCLogLFit(spec, bData(:,:,i));
        end
        stE = mean((bpars - repmat(params,[1, numsamples])).^2,2);
        
    case 'EM'
        if isempty(params) == 1
            params = RSCEMFit(spec, data); % Full likelihood
            spec.theta0 = params;
        else
            spec.theta0 = params; 
        end
        
        l = size(params,1);
        
        bpars = zeros(l,numsamples);
        
        for i = 1:numsamples
            fprintf('Estimating copula parameters for bootstrap sample number: %2i\n',i)
            bpars(:,i) = RSCEMFit(spec, bData(:,:,i));
        end
        bpars = bpars(1:end-3,:);
        pars = params(1:end-3,:);
        stE = mean((bpars - repmat(pars,[1, numsamples])).^2,2);
end
fprintf('Standard error calculation time: %4.2f minutes\n',toc/60)

DisplayResults(params,stE)
