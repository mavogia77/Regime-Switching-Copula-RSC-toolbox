function [LogL, LL, ksi] = RSCLogL(theta,data,spec, ksi)

% this function calculates the log likelihood of the regime switching
% copula, assuming that the dependence structure (the copula) is regime
% dependent.
% INPUTS: 
% theta:            vector of model parameters [θ1;θ2;π11;π22;z], where θ1
%                   and θ2 are the parameters of the copula in regimes 1
%                   and 2 respectively and π11 and π22 are the transition
%                   probabilities
% data:             Txn array with uniform U(0,1) margins. T is the number
%                   of observations and n the size. 
% spec:             The model specifications. Run RSspec to create it.
% ksi:              Tx2 array of forecast probabilities ξ_{t+1|t}
tic
c = zeros(size(data)); 
cp{1} = theta(1:spec.numparams(1));         % regime 1 copula parameters
cp{2} = theta(spec.numparams(1)+1:spec.numparams(1)+spec.numparams(2));     % regime 2 copula parameters

% pdf for regime s, s=1,2.
for s = 1:2
    c(:,s) = Copula_PDF(cp{s}, data, spec.Regime{s});
end

if nargin == 3
% forecast probabilities
    ksi = RSCfiltering(theta, data, spec);
end

% calculating the log likelihood of the Regime Switching Copula 
LL =log(c(:,1).*ksi(:,1)+c(:,2).*ksi(:,2));

LogL = -1*sum(LL);
