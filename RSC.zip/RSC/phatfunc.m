function phat = phatfunc(x,w,sw,trprobs)

% the probabilities of the form:
% Pr[S_t = i, S_{t-1} = j|Y_T; theta]
% equation 22 Cole

% ------ Cole ---------
% calculating state expectations:
% phat:      Array with four columns, each column consists of state
%            expectations, eg: 
%            phat(:,1) = E[(1-s_{t})(1-s_{t-1})|Y_T;theta]
%            phat(:,2) = E[s_{t}(1-s_{t-1})|Y_T;theta]
%            phat(:,3) = E[(-1+s_{t})s_{t-1)}|Y_T;theta]
%            phat(:,4) = E[s_{t} s_{t-1}|Y_T;theta]

%phat = phatfunc(x,w,sw,P);

T = size(sw,1);

p00 = x(1:T-1,1).*(sw(2:T,1)./w(2:T,1))*trprobs(1);
phat(:,1) = p00;

p01 = x(1:T-1,2).*(sw(2:T,1)./w(2:T,1))*(1 - trprobs(2));
phat(:,2) = p01;

p10 = x(1:T-1,1).*(sw(2:T,2)./w(2:T,2))*(1 - trprobs(1));
phat(:,3) = p10;

p11 = x(1:T-1,2).*(sw(2:T,2)./w(2:T,2))*trprobs(2);
phat(:,4) = p11;




