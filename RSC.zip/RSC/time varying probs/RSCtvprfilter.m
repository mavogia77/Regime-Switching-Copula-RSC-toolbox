function [LogL, fp, ip, tp] = RSCtvprfilter(theta, data, spec, lambda)
% This function applies the Hamilton filter to the 2 regime switching copula
% with time varying transition probabilities, following the GAS model of
% Creal et al (2013)
% INPUTS
% theta:                column vector of copula parameters of the form:
%                       [ cp1; cp2; omega1 omega2 AA1 AA2 BB1 BB2 zeta]
%                       where cp1 and cp2 are the regime specific copula
%                       parameters, zeta is the probabilitiy of being in
%                       the first state in t = 1 and the rest 6 parameters
%                       are from the GAS equation(s):
% -----------------------------------------------------------------------
% x_{t+1} = [omega1 omega2] + s_t*diag([AA1 AA2]) + x_t*diag([BB1 BB2]);
% tp_{t+1} = exp.^x_{t+1}./(1+exp.^x_{t+1})
% ------------------------------------------------------------------------
% data:                 Tx2 array of copula data (uniform margins)
% spec:                 Structure that contains the model specifications
% lambda:               Positive scalar, for the Trikhonov regularized matrix
%                       inverse

% OUTPUTS:
% fp:                   Tx2 array of filtered probabilities
% ip:                   Tx2 array of inference probabilities
% tp:                   Tx2 array of tive varying transition probabilities
% ------------------------------------------------------------------------
T = size(data,1);
% regime specific copula parameters
cp1 = theta(1:spec.numparams(1));         % regime 1 copula parameters
cp2 = theta(1+spec.numparams(1):sum(spec.numparams));   % regime 2 copula parameters

% the GAS equation is x_{t+1} = omega + s_t*AA' + x_t*BB';
% the GAS model parameters (6 real numbers)
omega = [theta(end - 6) theta(end - 5)];
AA = diag([theta(end-4) theta(end-3)]);
BB = diag([theta(end-2) theta(end-1)]);

% the initial state probability
z = theta(end);
 
w1= z; w2 = 1-w1; 

%w(1,:)=[w1 w2];

fp = repmat([w1 w2],[T 1]); % forecasted probabilities
ip = fp;

x = zeros(T,2);    x(1,:) = [log(.85/.15) log(.85/.15)];
tp = zeros(T,2);   tp(1,:) = [.85 .85];                    % [π_{00,t} π_{11,t}]
p = zeros(T,1);

g = zeros(T,2); delta = g; s = g;   % Tx2 arrays of zeros

cc = zeros(T,2); 
cc(:,1) = Copula_PDF(cp1, data, spec.Regime{1});
cc(:,2) = Copula_PDF(cp2, data, spec.Regime{2});
  
for t = 2:T
    
%   GAS updating mechanism            
    x(t,:) = omega + s(t-1,:)*AA' + x(t-1,:)*BB';

    tp(t,:) = exp(-x(t,:))./(1 + exp(-x(t,:)));

%   Inference probabilities    
    ip(t-1,:)= fp(t-1,:).*cc(t-1,:)/sum(fp(t-1,:).*cc(t-1,:));
    
%   eq 14    
    g(t,1) = tp(t,1).*(1-tp(t,1)).*ip(t-1,1);
    g(t,2) = -tp(t,2).*(1-tp(t,2)).*ip(t-1,2);

    Pt = [tp(t,1) 1-tp(t,2);1-tp(t,1) tp(t,2)];
    
%   eq 7    
    p(t,:) = cc(t,:)*Pt*ip(t-1,:)';
%   eq 13    
    delta(t,:) = (cc(t,1) - cc(t,2))/p(t,:)*g(t,:);

%   scaling matrix s_t
    St1 = g(t,:)'*g(t,:);
    
%   Trikhonov regularized matrix inverse    
    St = (lambda*eye(2) - (1-lambda)*St1)^(-.5);
    
    s(t,:) = delta(t,:)*St';

%   filtered probabilities
    fp(t,:) = ip(t-1,:)*Pt';
            
end

LL =log(cc(:,1).*fp(:,1)+cc(:,2).*fp(:,2));

LogL = -1*sum(LL);

%     if isreal(x(t,:)) == 0
%         fprintf('complex x in obs t: %2d\n',t)
%         break
%     end

%     if isreal(tp(t,:)) == 0
%         fprintf('complex tp in obs t: %2d\n',t)
%         break
%     end

%     if isreal(delta(t,:)) == 0
%         fprintf('complex delta in obs t: %2d\n',t)
%         break
%     end


%     if isreal(g(t,:)) == 0
%         fprintf('complex g in obs t: %2d\n',t)
%         break
%     end

