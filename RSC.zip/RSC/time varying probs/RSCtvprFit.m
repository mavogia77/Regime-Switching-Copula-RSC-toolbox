function [theta, LogL, evalmodel] = RSCtvprFit(spec, data, lambda)
% tested only for two Gaussian, static regimes

options2 = optimoptions(@fmincon,'Algorithm','interior-point','Display','iter','Hessian','bfgs','MaxFunEvals',12000);
options2 = optimoptions(options2,'FinDiffType','central','MaxIter',1000,'TolCon',10^-12,'TolFun',10^-4,'TolX',10^-4,'PlotFcn',{@optimplotx,...
    @optimplotfval,@optimplotfirstorderopt});
A = [0 0 0 0 1 0 1 0 0];
A = [A; 0 0 0 0 0 1 0 1 0];
b = .9999*[1; 1];
lb = [-.9;-.9;-10;-10; zeros(5,1)];
ub = [.9; .9; 10; 10; .9999*ones(4,1);1];

theta0 = spec.theta0;
clc

[theta, LogL, exit]= fmincon('RSCtvprfilter',theta0,[],[],A,b,lb,ub,[],options2, data, spec, lambda);
T = size(data,1);
m = length(theta);
evalmodel.theta = theta;
evalmodel.exitflag = exit;
if m>0
    [AIC,BIC] = aicbic(-LogL,m,T);
    evalmodel.AIC = AIC;
    evalmodel.BIC = BIC;
    evalmodel.LogL = -LogL;
end