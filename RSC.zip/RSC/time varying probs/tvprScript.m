%% USAGE

% this script simulates and estimates the parameters of an RS copula with two 
% static Gaussian regimes and time varying transition probabilities,
% following a GAS mechanism, in the spirit of the included paper.

% Unfortunately I couldn't make it to work...

% any suggestions or error corrections would be highly appreciated

% please contact at: vogia@yahoo.com


%% simulate time varying transition probabilities and corresponding data
x = linspace(1,2000,2000)';

p11 = .96 + .03*sin(pi*x/1000);

p22 = [.95*ones(1000,1); .99*ones(1000,1)];

% simulate state variable

state = simulateStateVariable(p11, p22, 2000);

%% simulate data
spec = RSCspec();
% Regime 1: Gaussian, static
% Regime 2: Gaussian, static
simData = simulateRSCdata(spec, state, [.5;.2]);

%% fit the data
spec.theta0 = [ .5; .2; -3 ; -3; 0.1; 0.1; .2;.2; 0.5];
[theta, LogL, evalmodel] = RSCtvprFit(spec, simData, .05);

%% check the fit
[ll, fp, ip, tp] = RSCtvprfilter(theta, simData, spec, .05);

% if the model worked fine the transition probabilities implied by the
% model and the simulated ones should be close

figure
subplot(1,2,1)
plot([p11, tp(:,1)])
title('real vs implied trans probabilities pi_{00}')

subplot(1,2,2)
plot([p22, tp(:,2)])
title('real vs implied trans probabilities pi_{11}')
