function [theta, LogL, evalmodel, spec] = RSCLogLFit(spec, data)

lb = spec.lb; ub = spec.ub;
A = spec.A; b = spec.b;


% options2 = optimset('Algorithm','interior-point','Display','iter','Hessian','bfgs','MaxFunEvals',12000);
% options2 = optimset(options2,'FinDiffType','central','MaxIter',1000,'TolCon',10^-12,'TolFun',10^-4,'TolX',10^-4,'PlotFcn',{@optimplotx,...
%     @optimplotfval,@optimplotfirstorderopt});
if isfield(spec,'bbmethod') == 1
    options2 = optimset('Algorithm','interior-point','Display','none','Hessian','bfgs','MaxFunEvals',12000);
    options2 = optimset(options2,'FinDiffType','central','MaxIter',1000,'TolCon',10^-12,'TolFun',10^-4,'TolX',10^-4);
else
    options2 = optimset('Algorithm','interior-point','Display','iter','Hessian','bfgs','MaxFunEvals',12000);
    options2 = optimset(options2,'FinDiffType','central','MaxIter',1000,'TolCon',10^-12,'TolFun',10^-4,'TolX',10^-4);
end

theta = spec.theta0;    
[params, LogL]= fmincon('RSCLogL',theta,A,b,[],[],lb,ub,[],options2,data,spec);
theta = params;
[w,x] = RSCfiltering(params, data, spec);
P = params(end-2:end-1);
sw = RSCsmoothing(P, w, x);

evalmodel.smoothpr = sw;
evalmodel.time = toc;
spec.theta = theta;
spec.est_method = 'Full MLE';