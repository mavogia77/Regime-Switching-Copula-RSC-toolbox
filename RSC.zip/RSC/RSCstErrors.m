function stErrors = RSCstErrors(MyFunc, theta, data, spec, type)
% Function to compute standard errors or robust standard error for RSC
% models

% INPUTS:
% MyFunc:           String, the log likelihood function
% theta:            array of parameters
% data:             copula data
% spec:             structure that contains the model specifications
% type:             string with values 'Fisher' or 'Godambe' (default).

% OUTPUTS:
% stErrors:         the square root of the diagonal elements of the
%                   variance covariance matrix
if nargin == 4
    type = 'Godambe';
end
T = size(data,1);
switch type
    case 'Fisher'
        Hnum = hessian_2sided(MyFunc,theta,data,spec); % calculates the numerical Hessian
        Hess = Hnum/T;
        VCV = inv(Hess)/T;
        stErrors = diag(sqrt(VCV));
    case 'Godambe'
        scores = MyFuncScores(MyFunc,theta,data, spec);%calculates the numerical gradient
        Hnum = hessian_2sided(MyFunc,theta,data,spec); % calculates the numerical Hessian
        Hess = Hnum/T;
        xx = Hess\cov(scores); % inv(Hess)*cov(scores)
        RobVCV = (xx/Hess)/T; % Godambe info matrix
        stErrors = diag(sqrt(RobVCV));
end

% print results to the screen
DisplayResults(theta,stErrors)

        
        