function [theta, LogL, evalmodel] = RSCFit(spec, data, method)
% Function to estimate the parameters of a regime switching copula model
% (RSC).

% INPUTS:
% spec:         structure array that defines the model. Run RSCspec to
%               obtain.
% data:         Array of copula data (uniform margins)
% method:       String with values 'Full MLE' and 'EM'. Defines the
%               estimation method.

% error checking

if max(max(data))>=1 || min(min(data))<0
    error('data should be uniform')
end

if nargin == 2
    method = 'Full MLE';
end

switch method
    case 'Full MLE'
        
        spec.est_method = 'Full MLE';
        [theta, LogL, evalmodel] = RSCLogLFit(spec, data);
        
    case 'EM'
        
        spec.est_method = 'EM';
        if isfield(spec,'numiters') == 1
            
            [theta, LogL, evalmodel] = RSCEMFit(spec, data);
            
        else
            
            xx = input('define  the number of EM iterations, enter for default = 50:');
            if isempty(xx) == 1
                spec.numiters = 50;
            else
                spec.numiters = xx;
            end
            
            [theta, LogL, evalmodel] = RSCEMFit(spec, data);
            
        end

end
T = size(data,1);
m = length(theta);
if m>0
    [AIC,BIC] = aicbic(-LogL,m,T);
    evalmodel.AIC = AIC;
    evalmodel.BIC = BIC;
    evalmodel.LogL = -LogL;
end
            