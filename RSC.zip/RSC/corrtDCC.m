function [Rt, gradRt, scoresRt] = corrtDCC(params, udata, Q0)
% Function that calculates the correlation matrix and its derivatives w.r.t. the
% parameters of the t - copula. 
% INPUTS:
% params:               3x1 coloumn vector of the DCC equation parameters
%                       (v,a,b)           
% udata:                Tx2 array with uniform margin
% OUTPUTS
% Rt:                   Tx1 array of Dynamic Conditional Correlations
% gradRt:               3x1 vector. Contains the sum of partial derivatives of Rt
%                       w.r.t. the t copula parameters (v,a,b)
% scoresRt:             Tx3 aray. Contains the partial derivatives of Rt
%                       w.r.t. the t copula parameters (v,a,b), at each t.
%                       It holds that gradRt = sum(scoresRt);
% -----------------------------------------------------------------------
% DCC equation(s): Rt = Qst*Qt*Qst (1)
%                  Qt = (1 - a - b)*Q0 + a * data(t-1,:)'*data(t-1,i) + b*Qt-1 (2)
% ------------------------------------------------------------------------
T = size(udata,1);
Rt = zeros(T,1);

if nargout == 1
    if nargin == 2
        [Qt, Qst] = covtDCC(params, udata);
    elseif nargin == 3
        [Qt, Qst] = covtDCC(params, udata, Q0);
    end
    for i=1:T
        rho = Qst(:,:,i)*Qt(:,:,i)*Qst(:,:,i);
        Rt(i)=rho(2,1);
        if Rt(i) >= 1
            Rt(i) = .9999;
        elseif Rt(i) <= 0
            Rt(i) = 10^-6;
        end
    end
else
    [Qt, Qst, dQtdv, dQtda, dQtdb] = covtDCC(params, udata);
    dRdv = zeros(T,1); dRda = dRdv; dRdb = dRdv;
    for i=1:T
        rho = Qst(:,:,i)*Qt(:,:,i)*Qst(:,:,i);
        Rt(i)=rho(2,1); 
        diagQt = diag(diag(Qt(:,:,i)).^-1.5);
        dQstda = -.5*diagQt.*dQtda(:,:,i);
        dQstdb = -.5*diagQt.*dQtdb(:,:,i);
        dQstdv = -.5*diagQt.*dQtdv(:,:,i);
        % to speed things up a little bit...
        QstQt = Qst(:,:,i)*Qt(:,:,i); QtQst = Qt(:,:,i)*Qst(:,:,i);
        
        drhoda = dQstda*QtQst + Qst(:,:,i)*dQtda(:,:,i)*Qst(:,:,i)+QstQt*dQstda;
        dRda(i) = drhoda(2,1);
        
        drhodb = dQstdb*QtQst + Qst(:,:,i)*dQtdb(:,:,i)*Qst(:,:,i)+QstQt*dQstdb;
        dRdb(i) = drhodb(2,1);
        
        drhodv = dQstdv*QtQst + Qst(:,:,i)*dQtdv(:,:,i)*Qst(:,:,i)+QstQt*dQstdv;
        dRdv(i) = drhodv(2,1);
    end
    scoresRt = [ dRdv dRda dRdb];
    gradRt = sum(scoresRt);
end
        
        