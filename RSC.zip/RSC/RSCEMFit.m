function [theta, LogL, evalmodel, spec] = RSCEMFit(spec, udata)

numiters = spec.numiters; % the max number of EM iterations

parameters = zeros(size(spec.theta0,1),numiters+1); % parameters from each iteration
parameters(:,1) = spec.theta0; params = spec.theta0;

LL = zeros(numiters+1,1);
dll = zeros(numiters,1);

lb = spec.lb(1:end-3); ub = spec.ub(1:end-3);
if isempty(spec.A) == 0
    spec.A = spec.A(:,1:end-3);
end

tic
options2 = optimset('Algorithm','interior-point','Display','none','Hessian','bfgs','MaxFunEvals',12000);
options2 = optimset(options2,'FinDiffType','central','MaxIter',1000,'TolCon',10^-12,'TolFun',10^-4,'TolX',10^-4);


spec.est_method = 'EM';

for i=1:numiters
    % fprintf('E - STEP, iteration number %2i:\n',i)
    %--------------------------- E - STEP ----------------------------------
    % use Hamilton filter to obtain inference and forecast prbabilities
    [fp,ip] = RSCfiltering(params, udata, spec);
    
    P = [params(end-2);params(end-1)]; 
    
    % use Kim's filter to obtain smoothed inference probabilities
    sp = RSCsmoothing(P, fp, ip);
    
    cpars = params(1:end-3);
    
    % calculate the log - likelihood
    if i == 1
        LL(1) = RSCLogL(params,udata,spec,fp);
    end
    
    %--------------------------- M - STEP -----------------------------------
    
    % estimate the copula parameters [cp1;cp2]
    [cpars, LL(i+1)] = fmincon('RSCLogL',cpars,spec.A,spec.b,[],[],lb,ub,[],options2,udata,spec,fp);
    
    % update the p00, p11 and z parameters for whom closed form solutions do exist
    phat = phatfunc(ip,fp,sp,P);
    
    % equation (25) Cole
    % p11 = sum(phat(2:end,1))/sum(sw(1:end-1,1));
    p11 = sum(phat(2:end,1))/sum(phat(2:end,1)+phat(2:end,3));
    % p22 = sum(phat(2:end,4))/sum(sw(1:end-1,2));
    p22 = sum(phat(2:end,4))/sum(phat(2:end,2)+phat(2:end,4));
    % equation (27) Cole
    nzeta = phat(1,1)+phat(1,3);
    
    nP = [p11;p22];
    nparams = [cpars;nP;nzeta]; % the new parameters vector
    parameters(:,i+1) = nparams;
    exDuration = [1/(1-p11) 1/(1-p22)];
    
    % ---------------- test for convergence ------------------------------
    dll(i) = abs(LL(i+1)) - abs(LL(i));
    tolx = max(abs(nparams - params));
    fprintf('EM algorithm iteration number %2i, LogL: %5.2f,    tolx: %8.5f\n',i,LL(i+1),tolx)

    if dll(i) >=0 && dll(i) < 10^(-4)
        disp('minimum found, log likelihood difference is less than tolerance')
        evalmodel.message = 'minimum found, log likelihood difference is less than tolerance';
        evalmodel.tolf = dll(i);
        evalmodel.tolx = tolx;
        evalmodel.numiters = i;
        evalmodel.parameters = parameters(:,1:i+1);
        evalmodel.LL = LL;
        evalmodel.smoothpr = sp;
        evalmodel.exDuration = exDuration;
        evalmodel.TimeInSeconds = toc;
        LogL = LL(i+1);
        theta = nparams;
        spec.theta = theta;
        break
    elseif tolx < 10^(-4)  
        disp('minimum found, parameters absolute difference is less than tolerance')
        evalmodel.message = 'minimum found, tolx is less than tolerance';
        evalmodel.tolf = dll(i);
        evalmodel.tolx = tolx;
        evalmodel.numiters = i;
        evalmodel.parameters = parameters(:,1:i+1);
        evalmodel.LL = LL;
        evalmodel.smoothpr = sp;
        evalmodel.exDuration = exDuration;
        evalmodel.TimeInSeconds = toc;
        LogL = LL(i+1);
        theta = nparams;
        spec.theta = theta;
        break
    elseif i>25 && mean(abs(dll(i-5:i)))<10^(-3) && tolx<10^(-3)
        disp('minimum possible, 5 iteration average log likelihood difference and tolx are less that 10^(-3)')
        evalmodel.tolf = dll(i);
        evalmodel.tolx = tolx;
        evalmodel.numiters = i;
        evalmodel.parameters = parameters(:,1:i+1);
        evalmodel.LL = LL;
        evalmodel.smoothpr = sp;
        evalmodel.exDuration = exDuration;
        evalmodel.TimeInSeconds = toc;
        LogL = LL(i+1);
        theta = nparams;
        spec.theta = theta;
        break
    elseif i == numiters
        disp('EM algorithm did not converge, increase number of iterations')
        theta = [];
        LogL = [];
        evalmodel.parameters = parameters;
    else
        params = nparams;
    end
end