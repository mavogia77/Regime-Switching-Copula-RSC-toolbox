function spec = RSCspec(data)
% defines the model specifications
% INPUTS
% data:              [T,2] matrix with uniform margins
% OUTPUTS
% spec:              Structure array that contains the following
% spec.Regime1:      The copula for regime 1, values are
%                   'Gaussian','t','Clayton','Gumbel' and 'SJC'
% spec.Regime2:      The copula for regime 2, values are
%                   'Gaussian','t','Clayton','Gumbel' and 'SJC'
% spec.type1:        String that defines if the copula parameter is static
%                    or time varying. For the Gaussian and t copula the
%                    values are 'static', or 'DCC', for the Clayton and
%                    Gumbel copula the values are 'static' or 'Patton'. For
%                    the SJC copula only the static option is allowed.
% spec.type2:        Exactly the same as spec.type1, only for the second
%                    regime.
% spec.P:            2x2 matrix of transition probabilities: 
%                    pij = Pr[S_t= i | S_{t-1}= j]
                     %with column sum equal to 1. Default P = [.8 .2;.2 .8]
% spec.theta0:       1x2 cell array of the initial values of copula
%                    parameters. 
% spec.zeta:         2x1 matrix of initial state probabilities ξ1_1|0
%                    and ξ2_1|0. The sum of the two elements should equal 1
% spec.params:       Column vector of RS copula parameters in the form
%                    [cp1;cp2;p11;p22;zeta] where cp1 is the vector of
%                    parameters of the copula in regime 1 and p11 is the
%                    transition probability. zeta is the initial value for
%                    the filter recursion
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 25/07/2018
if nargin == 0
    p = 2;
else
    p = size(data,2);
    if min(min(data))<0 || max(max(data))>1
    error('data should consist of uniform margins (columns)')
    end
end
spec.spec = 'Regime-Switching';
% basic error checking
if p == 1
    error('data should be multivariate')
end

% define initial transition probabilities
ba = input('define  2x1 vec of trans probs π11 and π22, enter for defaults:');
if isempty(ba)
    spec.P = [.9 .1;.1 .9];
else
    spec.P = [ba(1,1) 1-ba(2,1);1-ba(1,1) ba(2,1)];
end 

%spec.theta0 = cell(1,2);

% define the copula pdf for regime 1
% for bivariate data only there are 5 copula families available.
if p == 2
%   r = corr(data); rho = r(1,2);

    aa = menu('define the copula family of the first regime','t','Gaussian','Clayton','SJC','Gumbel');
    spec.type{1} = 'static';
    if aa == 1
        spec.Regime{1} = 't';
        theta0_1 = [3;.5]; % the degree of freedom parameter is set to 3 for Regime1
        lb1 = [2.01;-.95]; ub1 = [100;.95];
        spec.numparams(1) = 2;
    elseif aa == 2
        spec.Regime{1} = 'Gaussian';
        theta0_1 = .6; % the correlation coefficient is set to 0.6 for Regime1
        lb1 = -.9; ub1 = .9;
        spec.numparams(1) = 1;
    elseif aa == 3
        spec.Regime{1} = 'Clayton';
        theta0_1 = 0.6; % the kendall's tau is set to 0.6 for Regime1
        lb1 = .001; ub1=20;
        spec.numparams(1) = 1;
    elseif aa == 4
        spec.Regime{1} = 'SJC';
        theta0_1 = [.5;.5]; % the upper and lower tail dependence are set to 0.5
        lb1 = [0;0]; ub1 = [.99;.99];
        spec.numparams(1) = 2;
    elseif aa == 5
        spec.Regime{1} = 'Gumbel';
        spec.numparams(1) = 1;
        lb1 = 1; ub1 = 20;
        theta0_1 = 3;
    end

    spec.A1 = zeros(1,spec.numparams(1)); spec.b1 = 0;

    if aa == 1 || aa == 2
        aa1 = menu('define the evolution of the regime 1 copula parameter','static','DCC');
        if aa1 == 2 && aa == 1
            theta0_1 = [4;.05;.9]; lb1 = [10^(-8);10^(-8);2.01]; ub1 = [.5;.9995; 100];
            spec.A1 = [0 1 1]; spec.b1 = .9999;
            spec.numparams(1) = 3;
            spec.type{1} = 'DCC';
        elseif aa1 == 2 && aa == 2
            theta0_1 = [.05;.9]; lb1 = [10^(-8);10^(-8)]; ub1 = [.5;.9995];
            spec.A1 = [1 1]; spec.b1 = .9999;
            spec.numparams(1) = 2;
            spec.type{1} = 'DCC';
        end
    elseif aa == 3 || aa == 5
        aa2 = menu('define the evolution of the regime 1 copula parameter','static','Patton');
        if aa2 == 2 
            theta0_1 = [.1;.1;.1]; lb1 = -10*ones(3,1); ub1 = 10*ones(3,1);
            spec.numparams(1) = 3;
            spec.A1 = zeros(1,3);
            spec.type{1} = 'Patton';
        end
    end

    ab = menu('define the copula family of the second regime','t','Gaussian','Clayton','SJC','Gumbel');
    spec.type{2} = 'static';
    if  ab == 1
        spec.Regime{2} = 't';
        theta0_2 = [10;.25]; % the degree of freedom parameter is set to 10 for Regime2
        lb2 = [2.01;-.95]; ub2 = [100;.95];
        spec.numparams(2) = 2;
    elseif ab == 2
        spec.Regime{2} = 'Gaussian';
        theta0_2 = .25; 
        lb2 = -.9; ub2 = .9;
        spec.numparams(2) = 1;
    elseif ab == 3
        spec.Regime{2} = 'Clayton';
        theta0_2 = 0.2; % the kendall's tau is set to 0.2 for Regime2
        lb2 = .001; ub2=20;
        spec.numparams(2) = 1;
    elseif ab == 4
        spec.Regime{2} = 'SJC';
        theta0_2 = [.1;.1]; % the upper and lower tail dependence are set to 0.05
        lb2 = [.01;.01]; ub2 = [.99;.99];
        spec.numparams(2) = 2;
    elseif ab == 5
        spec.Regime{2} = 'Gumbel';
        spec.numparams(2) = 1;
        theta0_2 = 2;
        lb2 = 1; ub2 = 20;
    end

    spec.A2 = zeros(1,spec.numparams(2)); spec.b2 = 0;

    if ab == 1 || ab == 2
        aa3 = menu('define the evolution of the regime 2 copula parameter','static','DCC');
        if aa3 == 2 && ab == 1
            theta0_2 = [4;.05;.9]; lb2 = [10^(-8);10^(-8);2.01]; ub2 = [.5;.9995; 100];
            spec.A2 = [0 1 1]; spec.b2 = .9999;
            spec.numparams(2) = 3;
            spec.type{2} = 'DCC';
        elseif aa3 == 2 && ab == 2
            theta0_2 = [.05;.9]; lb2 = [10^(-8);10^(-8)]; ub2 = [.5;.9995];
            spec.A2 = [1 1]; spec.b2 = .9999;
            spec.numparams(2) = 2;
            spec.type{2} = 'DCC';
        end
    elseif ab == 3 || ab == 5
        aa4 = menu('define the evolution of the regime 2 copula parameter','static','Patton');
        if aa4 == 2 
            theta0_2 = [.1;.1;.1]; lb2 = -10*ones(3,1); ub2 = 10*ones(3,1);
            spec.numparams(2) = 3;
            spec.A2 = zeros(1,3);
            spec.type{2} = 'Patton';
        end
    end

spec.lb = [lb1;lb2;.5;.5;10^(-8)];
spec.ub = [ub1; ub2;10^6/(10^6+1);10^6/(10^6+1);10^6/(10^6+1)];
spec.theta0 = [theta0_1;theta0_2; spec.P(1,1);spec.P(2,2);.5];

if strcmp(spec.type{1},'static')==1 && strcmp(spec.type{2},'static')==1
    spec.A = []; spec.b =[];
else
    spec.A = [spec.A1 zeros(size(spec.A2)) zeros(1,3); zeros(size(spec.A1)) spec.A2 zeros(1,3)]; 
    spec.b = [spec.b1;spec.b2];
end

end

  
clc

%     ea = menu('define the estimation method','Full MLE','EM algorithm');
% 
%     if ea == 1
%         spec.est_method = 'Full MLE';
%     else
%         spec.est_method = 'EM';
%         ax = input('number of EM iterations? enter for default 15:');
%         if isempty(ax)
%             spec.numiters = 15;
%         else
%             spec.numiters = ax;
%         end
%     end

   